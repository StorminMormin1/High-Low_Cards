# High-Low_Cards
For L02 Developer Code Submission in CSE 210 - Brother Burton's class.

This is the code for 02-Developer Submission.
The program will create a simple card game of High/Low using a few classes
and their corresponding functions called methods.
